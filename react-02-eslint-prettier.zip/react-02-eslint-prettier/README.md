# Integrating ESLint and Prettier

## This is Practical 2 of LMS.

Integrate ESLint and Prettier in your React project. Use the recommended plugins for react and react hooks. You may want to refer to docs and read some blogs before you start to configure those tools in your React App.
# react-practical-2
# react-practical-2
