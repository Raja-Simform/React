function App() {
    return (
        <div className="container">
            <p>Hello, My name is Raja Jha.</p>
            <p>
                My email is :{' '}
                <a href="mailto:raja.jha@simformsolutions.com">
                    raja.jha@simformsolutions.com
                </a>
            </p>
            <p>
                My GitHub account :{' '}
                <a href="https://github.com/Raja-Simform">
                https://github.com/Raja-Simform
                </a>
            </p>
        </div>
    );
}

export default App;
