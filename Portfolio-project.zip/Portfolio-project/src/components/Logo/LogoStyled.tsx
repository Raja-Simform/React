import styled from "styled-components";
export const LogoStyled = styled.div`
  p {
    font-size: 1.5rem;
    font-weight: 700;
    margin: 0;
    color: #fdfbfb;
    font-family: 'Courier New', monospace;
  }
`;