export interface ProjectCardProps {
    githubProp: string;
    live: string;
    title: string;
    desc: string;
    technology: string[];
}