import styled from "styled-components";
export const ContainerStyled = styled.main`
  
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  padding-top: 40px; 
`;
