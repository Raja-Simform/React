import Card from './components/Card'
import './App.css'
function App() {
  return (
    <>
      <Card />
    </>
  )
}

export default App
