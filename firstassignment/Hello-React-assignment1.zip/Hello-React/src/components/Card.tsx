import "./Card.css";
function Card() {
  return (
    <>
      <div className="constainer">
        <div className="profile">
          <h1>Raja Jha</h1>
        </div>
        <div className="info">
          <h2>Email:-raja.jha@simformsolutions.com</h2>
          <h2>
            Github Account:https://github.com/Raja-Simform|
            <a href="https://github.com/Raja-Simform">
              click to visit My profile
            </a>
          </h2>
        </div>
        <div className="intro">
          <p>
            Myself Raja Jha, a final year Computer Engineeering student from LD
            College Of Engineering .Currently I am working as trainee in React
            at Simform Solutions......{" "}
          </p>
        </div>
      </div>
    </>
  );
}
export default Card;
